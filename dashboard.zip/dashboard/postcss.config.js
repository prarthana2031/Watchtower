module.exports = {
  plugins: {},
};